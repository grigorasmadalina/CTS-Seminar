package cts.grigoras.madalina.g1083.main;

import cts.grigoras.madalina.g1083.pattern.singleton.Robot;
import cts.grigoras.madalina.g1083.pattern.state.Cerere;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Robot robot1 = Robot.getInstance("Andreea", 1, "Verificare examen");
		Robot robot2 = Robot.getInstance("Madalina", 2, "Confirmare prezenta");
	    System.out.println(robot1.toString());
	    System.out.println(robot2.toString());
	    
	    
		Cerere cerere = new Cerere(3);
		cerere.confirmare();
		cerere.verificare();
		cerere.avizareDecanat();
		cerere.respingere();
		cerere.confirmare();
	    
	}

}
