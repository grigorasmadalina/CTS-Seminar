package cts.grigoras.madalina.g1083.pattern.singleton;

public class Robot implements IRobotSoftware{

	private String numeStudent;
	private int nrCerere;
	private String solicitari;
	
	private static Robot robot = null;
	
	public void setNumeStudent(String numeStudent) {
		this.numeStudent = numeStudent;
	}

	public void setNrCerere(int nrCerere) {
		this.nrCerere = nrCerere;
	}

	public void setSolicitari(String solicitari) {
		this.solicitari = solicitari;
	}
	
	

	public Robot(String numeStudent, int nrCerere, String solicitari) {
		super();
		this.numeStudent = numeStudent;
		this.nrCerere = nrCerere;
		this.solicitari = solicitari;
	}

	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Robot [numeStudent=");
		builder.append(numeStudent);
		builder.append(", nrCerere=");
		builder.append(nrCerere);
		builder.append(", solicitari=");
		builder.append(solicitari);
		builder.append("]");
		return builder.toString();
	}

	public static Robot getInstance(String numeStudent, int nrCerere, String solicitari) {
		if (robot == null) {
			robot = new Robot(numeStudent, nrCerere, solicitari);
		}
			return robot;
	}
	
	
	@Override
	public void trimiteCerere(String denumire) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getInformatii(String categorie) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void prelucrareCerere(String tip) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getIdRobot() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
