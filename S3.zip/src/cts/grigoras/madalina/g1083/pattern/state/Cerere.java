package cts.grigoras.madalina.g1083.pattern.state;

public class Cerere {
	private int nrCerere;
	private ICerereStudent stareCerere;
	
	public ICerereStudent  getStareCerere() {
		return stareCerere;
	}
	
	protected void setStareCerere(ICerereStudent  stareCerere) {
		this.stareCerere = stareCerere;
	}
	public int getNrCerere() {
		return nrCerere;
	}
	public Cerere(int nrCerere) {
		super();
		this.nrCerere = nrCerere;
		this.stareCerere = new CerereTrimisa();
	}
	
	public void confirmare() {
		CerereConfirmata cerereConfirmata = new CerereConfirmata();
		cerereConfirmata.confirmare();
	}
	public void verificare () {
		CerereVerificata cerereVerificata = new CerereVerificata();
		cerereVerificata.verificare();
	}
	public void avizareDecanat() {
		CerereAvizataDecanat cerereAvizataDecanat = new CerereAvizataDecanat();
		cerereAvizataDecanat.avizareDecanat();
	}
	public void respingere() {
		CerereRespinsa cerereRespinsa = new CerereRespinsa();
		cerereRespinsa.respingere();
	}

}
