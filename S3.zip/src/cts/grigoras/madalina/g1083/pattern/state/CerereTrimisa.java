package cts.grigoras.madalina.g1083.pattern.state;

public class CerereTrimisa implements ICerereStudent{

	@Override
	public void confirmare() {
		// TODO Auto-generated method stub
		
			System.out.println("Cererea nu poate sa fie trimisa");
	}

	@Override
	public void verificare() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void avizareDecanat() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void respingere() {
		// TODO Auto-generated method stub
		
	}



	
	

}
