package cts.grigoras.madalina.g1083.pattern.state;

public interface ICerereStudent {
    public void confirmare();

    public void verificare();

    public void avizareDecanat();

    public void respingere();

}